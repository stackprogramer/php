<!doctype html>
<html>
<head>
<!DOCTYPE html>
<?php 
	$name='col';
	$value=$_POST['color'];	
	setcookie($name,$value,time()+(86400*30),'/');	
	
?>
<meta charset="utf-8">
<title>color</title>
<style>
p{
	<?php
       echo "color:#".$value. ";"; 

    ?>
}
</style>
</head>

<body>

	<p>this is text</p>
</body>
</html>