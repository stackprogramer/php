
<html>
<head>
<title>cookie</title>
</head>
<body>

<form method="post" action="text.php">
<p>
	color:<select name="color">
    	<option value="">select</option>
        <option value="ff0000">red</option>
        <option value="0000ff">blue</option>
    </select>
</p>

<input type="submit" value="set"/>
</form>

</body>
</html>